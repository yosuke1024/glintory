import getpass
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from datetime import UTC, datetime


def get_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    zip_filename = "submission-glintory.zip"
    sha_filename = "submission-glintory.zip.sha256"

    # 1. Quality Gate Execution
    print("Running Quality Gate checks...")
    os.makedirs("logs", exist_ok=True)
    quality_status = {}
    ok = True

    # 1A. Pytest
    print("Executing pytest...")
    with open("logs/pytest.log", "w", encoding="utf-8") as f:
        res = subprocess.run(
            ["uv", "run", "pytest"], stdout=f, stderr=subprocess.STDOUT, check=False
        )
    if res.returncode == 0:
        quality_status["pytest"] = "passed"
    else:
        print("ERROR: pytest failed. See logs/pytest.log", file=sys.stderr)
        ok = False

    # 1B. Ruff check
    print("Executing ruff check...")
    with open("logs/ruff.log", "w", encoding="utf-8") as f:
        res = subprocess.run(
            ["uv", "run", "ruff", "check", "."],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if res.returncode == 0:
        quality_status["ruff"] = "passed"
    else:
        print("ERROR: ruff check failed. See logs/ruff.log", file=sys.stderr)
        ok = False

    # 1C. Ruff format check
    print("Executing ruff format check...")
    with open("logs/ruff.log", "a", encoding="utf-8") as f:
        f.write("\n\n--- FORMAT CHECK ---\n\n")
        res = subprocess.run(
            ["uv", "run", "ruff", "format", "--check", "."],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if res.returncode != 0:
        print("ERROR: ruff format check failed. See logs/ruff.log", file=sys.stderr)
        ok = False

    # 1D. Pyright
    print("Executing pyright...")
    with open("logs/pyright.log", "w", encoding="utf-8") as f:
        res = subprocess.run(
            ["uv", "run", "pyright"], stdout=f, stderr=subprocess.STDOUT, check=False
        )
    if res.returncode == 0:
        quality_status["pyright"] = "passed"
    else:
        print("ERROR: pyright failed. See logs/pyright.log", file=sys.stderr)
        ok = False

    # 1E. Alembic migrations check & roundtrip
    print("Executing alembic roundtrip migrations...")
    with open("logs/migration_roundtrip.log", "w", encoding="utf-8") as f:
        f.write("--- Upgrade Head ---\n")
        res1 = subprocess.run(
            ["uv", "run", "alembic", "upgrade", "head"],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=False,
        )
        f.write("\n--- Downgrade -1 ---\n")
        res2 = subprocess.run(
            ["uv", "run", "alembic", "downgrade", "-1"],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=False,
        )
        f.write("\n--- Upgrade Head (Again) ---\n")
        res3 = subprocess.run(
            ["uv", "run", "alembic", "upgrade", "head"],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if res1.returncode == 0 and res3.returncode == 0:
        quality_status["alembic_check"] = "passed"
    else:
        print(
            "ERROR: alembic check failed. See logs/migration_roundtrip.log",
            file=sys.stderr,
        )
        ok = False
    if res2.returncode == 0:
        quality_status["alembic_roundtrip"] = "passed"
    else:
        print(
            "ERROR: alembic roundtrip failed. See logs/migration_roundtrip.log",
            file=sys.stderr,
        )
        ok = False

    # 1F. Publish Build & Contract Validation
    print("Executing glintory publish build and validation...")
    if os.path.exists("dist_temp"):
        shutil.rmtree("dist_temp")
    try:
        # Generate real build data into dist_temp
        subprocess.run(
            [
                "uv",
                "run",
                "glintory",
                "publish",
                "build",
                "--output-dir",
                "dist_temp",
                "--site-url",
                "https://example.com",
            ],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        print(f"ERROR: glintory publish build failed: {e}", file=sys.stderr)
        ok = False

    with open("logs/contract_validation.log", "w", encoding="utf-8") as f:
        res_val = subprocess.run(
            [
                "uv",
                "run",
                "glintory",
                "publish",
                "validate-contract",
                "--dir",
                "dist_temp/data/v1",
            ],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if res_val.returncode == 0:
        quality_status["validate_contract"] = "passed"
    else:
        print(
            "ERROR: contract validation failed. See logs/contract_validation.log",
            file=sys.stderr,
        )
        ok = False

    if not ok:
        print(
            "ERROR: Quality Gate checks failed. Submission ZIP will not be generated.",
            file=sys.stderr,
        )
        if os.path.exists("dist_temp"):
            shutil.rmtree("dist_temp")
        sys.exit(1)

    # 2. Get git commit SHA
    try:
        commit_sha = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True
        ).strip()
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Failed to get git commit SHA: {e}", file=sys.stderr)
        if os.path.exists("dist_temp"):
            shutil.rmtree("dist_temp")
        sys.exit(1)

    print(
        f"Creating {zip_filename} using tracked files from working tree (Commit {commit_sha})..."
    )

    # Get the list of tracked files
    try:
        tracked_files = subprocess.check_output(
            ["git", "ls-files"], text=True
        ).splitlines()
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Failed to retrieve git tracked files: {e}", file=sys.stderr)
        if os.path.exists("dist_temp"):
            shutil.rmtree("dist_temp")
        sys.exit(1)

    # Write files directly from working tree into the ZIP
    try:
        with zipfile.ZipFile(zip_filename, "w") as zf:
            for file_path in tracked_files:
                if os.path.exists(file_path):
                    zf.write(file_path, file_path)
    except Exception as e:
        print(f"ERROR: Failed to write tracked files to ZIP: {e}", file=sys.stderr)
        if os.path.exists("dist_temp"):
            shutil.rmtree("dist_temp")
        sys.exit(1)

    # Define forbidden directories and extensions for safety scans
    forbidden_dirs = [
        "models/",
        "bin/",
        "build/",
        ".state/",
        "data/",
        "invalid/",
        "__pycache__/",
    ]
    forbidden_exts = [
        ".pyc",
        ".pyo",
        ".db",
        ".sqlite",
        ".sqlite3",
        ".gguf",
        ".so",
        ".dylib",
        ".dll",
        ".zip",
        ".tar",
        ".tar.gz",
    ]

    # Get current username
    username = getpass.getuser()
    forbidden_paths = [
        f"/Users/{username}/",
        f"/home/{username}/",
        "file:/" + "/Users/",
    ]

    # Secret and mock values check details
    confidential_markers = [
        "TOKEN_SECRET_12345",
        "sqlite:///private-secret-db.sqlite3",
        "/Users/example/private/model.gguf",
        "https://private.example/path",
    ]

    # Strict allowlist: { file_path: [ allowed_markers ] }
    secret_allowlist = {
        "scripts/create_submission.py": [
            "TOKEN_SECRET_12345",
            "sqlite:///private-secret-db.sqlite3",
            "/Users/example/private/model.gguf",
            "https://private.example/path",
        ],
        "tests/test_entrypoint.py": [
            "TOKEN_SECRET_12345",
            "sqlite:///private-secret-db.sqlite3",
            "/Users/example/private/model.gguf",
            "https://private.example/path",
        ],
        "tests/services/test_opportunity_enrichment.py": ["TOKEN_SECRET_12345"],
        ".github/workflows/local-llm-smoke.yml": [
            "TOKEN_SECRET_12345",
            "sqlite:///private-secret-db.sqlite3",
            "/Users/example/private/model.gguf",
            "https://private.example/path",
        ],
    }

    print("Verifying the generated zip archive safety and cleanliness...")
    zip_ok = True

    with zipfile.ZipFile(zip_filename, "r") as zf:
        namelist = zf.namelist()
        for name in namelist:
            lower_name = name.lower()

            for f_dir in forbidden_dirs:
                if lower_name.startswith(f_dir) or f"/{f_dir}" in lower_name:
                    print(
                        f"ERROR: Forbidden directory structure detected: {name}",
                        file=sys.stderr,
                    )
                    zip_ok = False

            for f_ext in forbidden_exts:
                if lower_name.endswith(f_ext):
                    print(
                        f"ERROR: Forbidden extension detected: {name}", file=sys.stderr
                    )
                    zip_ok = False

            if lower_name == ".env" or lower_name.endswith("/.env"):
                print(f"ERROR: Forbidden .env file detected: {name}", file=sys.stderr)
                zip_ok = False

            is_text = False
            text_exts = [
                ".py",
                ".toml",
                ".yml",
                ".yaml",
                ".ini",
                ".json",
                ".txt",
                ".md",
                ".sh",
                ".sql",
            ]
            for ext in text_exts:
                if lower_name.endswith(ext):
                    is_text = True
                    break

            if is_text:
                try:
                    content = zf.read(name).decode("utf-8", errors="ignore")
                    for p in forbidden_paths:
                        if p in content:
                            print(
                                f"ERROR: Local path leak detected in '{name}': contains '{p}'",
                                file=sys.stderr,
                            )
                            zip_ok = False

                    for marker in confidential_markers:
                        if marker in content:
                            allowed_markers = secret_allowlist.get(name, [])
                            if marker not in allowed_markers:
                                print(
                                    f"ERROR: Unauthorized secret/mock value found in '{name}'",
                                    file=sys.stderr,
                                )
                                zip_ok = False
                except Exception as e:
                    print(
                        f"WARNING: Could not parse text content of {name}: {e}",
                        file=sys.stderr,
                    )

    if not zip_ok:
        print("Verification failed. Removing ZIP archive.", file=sys.stderr)
        if os.path.exists(zip_filename):
            os.remove(zip_filename)
        if os.path.exists("dist_temp"):
            shutil.rmtree("dist_temp")
        sys.exit(1)

    # 4. Generate SUBMISSION_MANIFEST.json and append validation logs, dist/data/v1/ to ZIP
    manifest_data = {
        "git_commit": commit_sha,
        "generated_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "archive_sha256": "<recorded in separate file after generation>",
        "quality_gate": {
            "pytest": quality_status.get("pytest", "failed"),
            "ruff": quality_status.get("ruff", "failed"),
            "pyright": quality_status.get("pyright", "failed"),
            "alembic_check": quality_status.get("alembic_check", "failed"),
            "alembic_roundtrip": quality_status.get("alembic_roundtrip", "failed"),
            "validate_contract": quality_status.get("validate_contract", "failed"),
        },
    }

    # Append manifest, logs and build artifacts to ZIP
    with zipfile.ZipFile(zip_filename, "a") as zf:
        zf.writestr("SUBMISSION_MANIFEST.json", json.dumps(manifest_data, indent=2))

        # Append validation logs
        log_files = [
            "logs/pytest.log",
            "logs/ruff.log",
            "logs/pyright.log",
            "logs/migration_roundtrip.log",
            "logs/contract_validation.log",
        ]
        for lf in log_files:
            if os.path.exists(lf):
                zf.write(lf, lf)

        # Append dist/data/v1/ from dist_temp
        dist_data_dir = "dist_temp/data/v1"
        for root, _, files in os.walk(dist_data_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, "dist_temp")
                archive_name = os.path.join("dist", rel_path)
                zf.write(full_path, archive_name)

    # Clean up temporary build dir
    if os.path.exists("dist_temp"):
        shutil.rmtree("dist_temp")

    # Calculate final SHA-256
    zip_sha = get_sha256(zip_filename)
    with open(sha_filename, "w", encoding="utf-8") as f:
        f.write(f"{zip_sha}\n")

    print(f"SUBMISSION_MANIFEST.json and quality artifacts appended to {zip_filename}.")
    print(f"SHA-256 written to {sha_filename}: {zip_sha}")

    # 5. Final Assertions (extract to check existence and key configurations)
    print("Running final assertions on ZIP contents...")
    final_ok = True
    with zipfile.ZipFile(zip_filename, "r") as zf:
        zip_entries = zf.namelist()

        # check files
        required_files = [
            "src/glintory/entrypoint.py",
            "tests/test_entrypoint.py",
            "scripts/create_submission.py",
            "pyproject.toml",
            ".github/workflows/local-llm-smoke.yml",
            "dist/data/v1/manifest.json",
            "dist/data/v1/opportunities.json",
            "dist/data/v1/feeds/jurypress.json",
            "logs/pytest.log",
            "logs/contract_validation.log",
        ]
        for rf in required_files:
            if rf not in zip_entries:
                print(
                    f"ERROR Assertion failed: '{rf}' is missing from the ZIP",
                    file=sys.stderr,
                )
                final_ok = False

        if "pyproject.toml" in zip_entries:
            pyproject_content = zf.read("pyproject.toml").decode(
                "utf-8", errors="ignore"
            )
            if "glintory.entrypoint:main" not in pyproject_content:
                print(
                    "ERROR Assertion failed: 'glintory.entrypoint:main' not found in pyproject.toml",
                    file=sys.stderr,
                )
                final_ok = False

        if ".github/workflows/local-llm-smoke.yml" in zip_entries:
            workflow_content = zf.read(".github/workflows/local-llm-smoke.yml").decode(
                "utf-8", errors="ignore"
            )
            if "rss_sample_count" not in workflow_content:
                print(
                    "ERROR Assertion failed: 'rss_sample_count' not found in local-llm-smoke.yml",
                    file=sys.stderr,
                )
                final_ok = False

    if not final_ok:
        print("Final assertions failed. Removing ZIP archive.", file=sys.stderr)
        if os.path.exists(zip_filename):
            os.remove(zip_filename)
        sys.exit(1)

    print("Verification success. ZIP archive is safe, clean, and fully conforming.")


if __name__ == "__main__":
    main()
