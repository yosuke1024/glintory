import pathlib
import sys
from logging.config import fileConfig

from alembic import context

# Add src/ to sys.path so we can import glintory packages inside migrations
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / "src"))

from glintory.config import settings
from glintory.domain.models import Base
from glintory.infrastructure.database import get_engine

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Set up metadata for autogenerate support
target_metadata = Base.metadata


def include_object(object_, name, type_, reflected, compare_to):
    # Ignore FTS5 virtual table and its shadow tables in Alembic migrations
    return not (
        type_ == "table" and (name == "signals_fts" or name.startswith("signals_fts_"))
    )


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    # Fetch database url dynamically from Settings instead of alembic.ini
    url = settings.database_url
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_object=include_object,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    # Check if a connection was explicitly passed via attributes (e.g. from tests)
    explicit_connection = config.attributes.get("connection")
    if explicit_connection is not None:
        context.configure(
            connection=explicit_connection,
            target_metadata=target_metadata,
            include_object=include_object,
        )
        with context.begin_transaction():
            context.run_migrations()
        return

    # Use our centralized get_engine() to inherit SQLite connection configurations (PRAGMAs, WAL, directory creation)
    connectable = get_engine()

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_object=include_object,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
